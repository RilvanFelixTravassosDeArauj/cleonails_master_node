this.getUsuarios = function (connection, callback){
    connection.query("SELECT * FROM usuario", callback);
        
}
this.getUsuariosId = function (id, connection, callback){
    connection.query ("SELECT * FROM usuario WHERE id = " +id, callback);
    
}
this.getUsuariosEmail = function (id, connection, callback){
    connection.query ("SELECT * FROM usuario WHERE id = " +email, callback);
}
this.getUsuarios = function (usuario, connection, callback){
    connection.query ('insert into usuario set ?, usuario');
}

return this;